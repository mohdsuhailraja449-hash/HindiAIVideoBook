Hindi AI Video Banane Ki Book - Android project

यह एक शुरुआती Android WebView ऐप प्रोजेक्ट है। इसमें आपकी HTML कहानी/सीन-प्रॉम्प्ट डेमो स्क्रीन ऐप के अंदर खुलती है।

APK बनाने के लिए:
1. इस ZIP को कंप्यूटर में Extract करें।
2. Android Studio खोलें।
3. File > Open चुनें और इस फोल्डर को चुनें।
4. Gradle Sync पूरा होने दें। Android SDK Platform 35 और JDK 17 की जरूरत पड़ सकती है।
5. ऊपर Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
6. APK app/build/outputs/apk/debug/app-debug.apk में मिलेगा।

ध्यान दें:
- यह अभी शुरुआती APK प्रोजेक्ट है, असली AI वीडियो जनरेशन नहीं।
- मौजूदा HTML डेमो नमूना कहानी और सीन प्रॉम्प्ट बनाता है।
- असली AI कहानी/इमेज/वीडियो के लिए सुरक्षित backend और अलग AI सेवा/API जोड़नी होगी।
- API keys को APK या HTML में सीधे न रखें।
- Google Play पर प्रकाशित करने से पहले ऐप की सुरक्षा, गोपनीयता नीति और परीक्षण जरूरी हैं।
